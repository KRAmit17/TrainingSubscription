using NUnit.Framework;
using TraningPortal.Services;

namespace TrainingPortalTesting
{
    public class Tests
    {
        ISubscription Sub;
        [SetUp]
        public void Setup(ISubscription _sub)
        {
            Sub = _sub;
        }

        [Test]
        public void Test1()
        {
            var val = Sub.GetSubscriptionList(1, 10);
            if (val != null)
                Assert.Pass();
            else
                Assert.Fail();
        }
    }
}