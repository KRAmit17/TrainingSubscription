﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TraningPortal.Services;
using TraningPortal.Data;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
//using System.Web.Http.Result;

namespace TraningPortal.Controllers
{
    [EnableCors("CorsPolicy")]
    [Route("api/[controller]")]
    [ApiController]
    public class TrainingController : ControllerBase
    {
        ITraining Tr;
        public TrainingController(ITraining tr)
        {
            Tr = tr;
        }
        
        public IActionResult Get([FromBody] dynamic dr)
        {
            return Ok(dr);
        }

        [HttpPost("createtraining")]
        public IActionResult Post([FromBody] Trainings dr)
        {

            if (!dr.Equals(null))
            {
                int val = Tr.CreatetandUpdateTraining(dr);
            if (val > 0)
                return Ok();
            else
                return StatusCode((int)HttpStatusCode.OK, "No New Training Created");
            }
            else
            return StatusCode((int) HttpStatusCode.OK, "No Training Data");
            
        }

        [HttpPost("upadetraining")]
        public IActionResult UpadeTraining([FromBody] Trainings dr)
        {

            if (!dr.Equals(null))
            {
                int val = Tr.CreatetandUpdateTraining(dr);
                if (val > 0)
                    return Ok();
                else
                    return StatusCode((int)HttpStatusCode.OK, "Training not Updated");
            }
            else
                return StatusCode((int)HttpStatusCode.OK, "No Training Data");

        }

    }
}
