﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TraningPortal.Data;
using TraningPortal.Services;

namespace TraningPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscriptionController : ControllerBase
    {
        ISubscription Sub;
        public SubscriptionController(ISubscription _sub)
        {
            Sub = _sub;
        }
        [HttpPost("AddSubscription")]
        public IActionResult CreateSubsCription([FromBody]Subscription sub)
        {
            if (!sub.Equals(null))
            {
                int val = Sub.CreateSubscription(sub);
                if (val > 0)
                    return Ok();
                else
                    return Ok("No Subscription Added");
            }
            else
                return StatusCode((int)HttpStatusCode.OK, "No Subscription Data");
            
        }

        [HttpGet("SubscriptionList")]
        public dynamic GetSubscriptionList(int pageno,int pagesize)
        {
            return Sub.GetSubscriptionList(pageno, pagesize);
        }
        [HttpGet("Sreach")]
        public dynamic SubscriptionSearch(string str)
        {
            return Sub.SubscriptionSearch(str);
        }
    }
}
