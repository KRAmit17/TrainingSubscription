﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TraningPortal.Data;

namespace TraningPortal.Services
{
    public class Training : ITraining
    {
        TrainingContext Tr;
        public Training()
        {
            Tr = new TrainingContext();
        }

        public int CreatetandUpdateTraining(Trainings tran)
        {
            

            if(!tran.Equals(null))
            {
                var code = Tr.Trainings.Where(x => x.Code == tran.Code).Select(x=>x.Code).SingleOrDefault();
                if (String.IsNullOrEmpty(code))
                {
                    var addtr = Tr.Courses.Where(x => x.Code == tran.Course).Select(x => x.Status).SingleOrDefault();
                    if (addtr.ToString().ToUpper() == "ACTIVE")
                    {
                        Tr.Add(tran);
                        return Tr.SaveChanges();
                    }
                    else
                        return 0;
                }
                else
                {
                    Trainings updatetr = Tr.Trainings.Where(x => x.Code == tran.Code).SingleOrDefault();
                    //Tr.Update(modtarining);
                    updatetr.Name = tran.Name;
                    updatetr.Course = tran.Course;
                    updatetr.Month = tran.Month;
                    updatetr.Status = tran.Status;
                    return Tr.SaveChanges();

                }
            }
            else
            {
                return 0;
            }
        }

    }
}
