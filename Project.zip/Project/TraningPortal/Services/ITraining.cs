﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TraningPortal.Data;

namespace TraningPortal.Services
{
    public interface ITraining
    {
        int CreatetandUpdateTraining(Trainings tr);

        //int UpdateTrainig(Trainings tr);
       
    }
}
