﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TraningPortal.Data;

namespace TraningPortal.Services
{
    public class Subscriptions : ISubscription
    {
        List<Users> user;
        TrainingContext Subs;
        public Subscriptions()
        {
            user = new List<Users>();
            Subs = new TrainingContext();
            UserList();
        }
        public async void UserList()
        {
            await GetUser();
        }
        private async Task GetUser()
        {
            
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://gorest.co.in/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method
                HttpResponseMessage response = await client.GetAsync("public/v2/users");
                if (response.IsSuccessStatusCode)
                {
                    var users = await response.Content.ReadAsAsync<IEnumerable<Users>>();
                    foreach(var usr in users)
                    {
                        user.Add(usr);
                    }
                }
                else
                {
                    Console.WriteLine("Internal server Error");
                }
            }
        }
        public int CreateSubscription(Subscription sub)
        {
           
            if (!sub.Equals(null))
            {
                var USER = user.Where(x => x.Id == sub.Userid).FirstOrDefault();
                if (USER != null)
                {
                    sub.UserName = USER.Name;
                    Subs.Add(sub);
                   return Subs.SaveChanges();
                }
                
            }

            return 0;
        }

        public dynamic GetSubscriptionList(int pageNumber, int pageSize)
        {
            var subcription = (from sb in Subs.Subscription
                              join tr in Subs.Trainings on sb.TrainingCode equals tr.Code
                              join crs in Subs.Courses on tr.Course equals crs.Code
                              join usr in user on sb.Userid equals usr.Id
                              select new
                              {
                                  TrainingCode = tr.Code,
                                  TainingName = tr.Name,
                                  CourseName = crs.Name,
                                  CourseCode = crs.Code,
                                  TrainingMonth = tr.Month,
                                  UserName = usr.Name,
                                  UserGender = usr.Gender,
                                  UserEmail = usr.Email
                              }).ToList().Skip((pageNumber - 1) * pageSize).Take(pageSize);
            
            return subcription;
        }

        public dynamic SubscriptionSearch(string str)
        {
            var subserch = (from sb in Subs.Subscription
                            join tr in Subs.Trainings on sb.TrainingCode equals tr.Code
                            join crs in Subs.Courses on tr.Course equals crs.Code
                            join usr in user on sb.Userid equals usr.Id
                            select new
                            {
                                TrainingCode = tr.Code,
                                TainingName = tr.Name,
                                CourseName = crs.Name,
                                CourseCode = crs.Code,
                                TrainingMonth = tr.Month,
                                UserName = usr.Name,
                                UserGender = usr.Gender,
                                UserEmail = usr.Email
                            }).Where(x => (x.CourseName == str) || (x.TrainingMonth == str) || (x.UserName == str) || (x.TainingName == str)).ToList();

            return subserch;
        }

    }
}
