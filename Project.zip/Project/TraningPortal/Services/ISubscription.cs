﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TraningPortal.Data;

namespace TraningPortal.Services
{
    public interface ISubscription
    {
        int CreateSubscription(Subscription sb);
        dynamic GetSubscriptionList(int pageNumber, int pageSize);

        dynamic SubscriptionSearch(string str);
    }
}
