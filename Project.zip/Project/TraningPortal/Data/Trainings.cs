﻿using System;
using System.Collections.Generic;

namespace TraningPortal.Data
{
    public partial class Trainings
    {
        public Trainings()
        {
            Subscription = new HashSet<Subscription>();
        }

        public string Code { get; set; }
        public string Name { get; set; }
        public string Course { get; set; }
        public string Month { get; set; }
        public string Status { get; set; }

        public virtual Courses CourseNavigation { get; set; }
        public virtual ICollection<Subscription> Subscription { get; set; }
    }
}
