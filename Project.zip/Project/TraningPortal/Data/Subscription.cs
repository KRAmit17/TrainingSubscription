﻿using System;
using System.Collections.Generic;

namespace TraningPortal.Data
{
    public partial class Subscription
    {
        public string Code { get; set; }
        public int Userid { get; set; }
        public string UserName { get; set; }
        public string TrainingCode { get; set; }

        public virtual Trainings TrainingCodeNavigation { get; set; }
    }
}
